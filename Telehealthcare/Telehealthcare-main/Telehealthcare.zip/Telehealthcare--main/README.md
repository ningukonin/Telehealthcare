# TELE HEALTHCARE DYNAMIC WEB APPLICATION:

Developed and implemented a tele healthcare system aimed at improving access to healthcare services for remote patients.

Tech Stack: 
            Utilized Html, Css, and JavaScript for frontend
development, while leveraging Java, JDBC,J2EE,Tomcat server (v9.1), and
Oracle Database on the backend to ensure efficient data processing
and storage
